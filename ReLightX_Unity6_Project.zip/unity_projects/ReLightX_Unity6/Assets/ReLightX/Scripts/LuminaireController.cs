using UnityEngine;

namespace ReLightX
{
    public class LuminaireController : MonoBehaviour
    {
        public string luminaireId;
        public string poleId;
        public string direction;
        [Range(0f, 1f)] public float currentBrightness = 0.3f;
        [Range(0f, 1f)] public float targetBrightness = 0.3f;
        public float riseSpeed = 4.2f;
        public float fallSpeed = 0.38f;
        public Light roadwayLight;
        public Renderer lensRenderer;

        private Material _runtimeMaterial;

        private void Awake()
        {
            if (roadwayLight == null)
            {
                roadwayLight = gameObject.AddComponent<Light>();
                roadwayLight.type = LightType.Spot;
                roadwayLight.range = 62f;
                roadwayLight.spotAngle = 66f;
                roadwayLight.innerSpotAngle = 42f;
                roadwayLight.shadows = LightShadows.Soft;
            }

            if (lensRenderer != null)
            {
                _runtimeMaterial = lensRenderer.material;
            }
        }

        private void Update()
        {
            float speed = targetBrightness > currentBrightness ? riseSpeed : fallSpeed;
            currentBrightness = Mathf.MoveTowards(currentBrightness, targetBrightness, speed * Time.deltaTime);
            ApplyBrightness(currentBrightness);
        }

        public void SetTarget(float brightness)
        {
            targetBrightness = Mathf.Clamp01(brightness);
        }

        public void ForceBrightness(float brightness)
        {
            currentBrightness = Mathf.Clamp01(brightness);
            targetBrightness = currentBrightness;
            ApplyBrightness(currentBrightness);
        }

        private void ApplyBrightness(float brightness)
        {
            if (roadwayLight != null)
            {
                roadwayLight.range = Mathf.Lerp(42f, 72f, brightness);
                roadwayLight.spotAngle = Mathf.Lerp(48f, 72f, brightness);
                roadwayLight.innerSpotAngle = Mathf.Lerp(30f, 48f, brightness);
                roadwayLight.intensity = Mathf.Lerp(0.35f, 18.0f, brightness);
                roadwayLight.color = Color.Lerp(new Color(1f, 0.62f, 0.32f), new Color(1f, 0.92f, 0.68f), brightness);
            }

            if (_runtimeMaterial != null)
            {
                Color emissive = Color.Lerp(new Color(0.35f, 0.25f, 0.12f), new Color(1f, 0.92f, 0.72f), brightness);
                _runtimeMaterial.EnableKeyword("_EMISSION");
                _runtimeMaterial.SetColor("_EmissionColor", emissive * Mathf.Lerp(0.4f, 2.8f, brightness));
            }
        }
    }
}
