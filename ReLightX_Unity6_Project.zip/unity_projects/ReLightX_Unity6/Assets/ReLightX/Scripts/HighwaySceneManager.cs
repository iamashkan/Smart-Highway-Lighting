using System;
using System.Collections.Generic;
using UnityEngine;

namespace ReLightX
{
    [Serializable]
    public class LuminaireState
    {
        public string luminaire_id;
        public string pole_id;
        public string direction;
        public float current_brightness;
        public float target_brightness;
        public float health_score;
        public float driver_temperature;
        public string fault_status;
        public string rex_status;
    }

    public class HighwaySceneManager : MonoBehaviour
    {
        public int numPoles = 96;
        public float poleSpacingM = 22f;
        public int zoneSizePoles = 9;
        public float ecoBrightness = 0.30f;
        public float heldBrightness = 0.62f;
        public float lightHoldSeconds = 3.2f;
        public float emergencyBrightness = 1.0f;
        public bool generateOnStart = true;
        public Material poleMaterial;
        public Material lensMaterial;
        public Material roadMaterial;
        public Material laneMarkerMaterial;
        public Material guardrailMaterial;
        public Material medianMaterial;
        public Material mountainMaterial;
        public Material forestMaterial;

        private readonly Dictionary<string, PoleManager> _poles = new Dictionary<string, PoleManager>();
        private readonly Dictionary<string, LuminaireController> _luminaires = new Dictionary<string, LuminaireController>();
        private readonly Dictionary<string, float> _lightHoldUntil = new Dictionary<string, float>();
        private MQTTClientBridge _mqttBridge;

        public float RoadLengthM => Mathf.Max(0f, (numPoles - 1) * poleSpacingM);

        private void Start()
        {
            if (generateOnStart)
            {
                BuildScene();
            }
            _mqttBridge = GetComponent<MQTTClientBridge>();
            if (_mqttBridge != null)
            {
                _mqttBridge.MessageReceived += HandleMqttMessage;
            }
        }

        private void OnDestroy()
        {
            if (_mqttBridge != null)
            {
                _mqttBridge.MessageReceived -= HandleMqttMessage;
            }
        }

        public void BuildScene()
        {
            ClearGeneratedObjects();
            CreateRoad();
            for (int i = 0; i < numPoles; i++)
            {
                string poleId = $"P{i + 1:000}";
                string zoneId = $"Z{i / zoneSizePoles:00}";
                PoleManager pole = CreatePole(poleId, i, zoneId, i * poleSpacingM);
                _poles[poleId] = pole;
                _luminaires[pole.luminaireA.luminaireId] = pole.luminaireA;
                _luminaires[pole.luminaireB.luminaireId] = pole.luminaireB;
            }
        }

        public void ApplyAdaptiveLightingFromVehicles(IReadOnlyList<VehicleController> vehicles)
        {
            float now = Time.time;
            foreach (LuminaireController luminaire in _luminaires.Values)
            {
                if (_lightHoldUntil.TryGetValue(luminaire.luminaireId, out float holdUntil) && holdUntil > now)
                {
                    luminaire.SetTarget(Mathf.Max(ecoBrightness, heldBrightness, luminaire.targetBrightness));
                }
                else
                {
                    luminaire.SetTarget(ecoBrightness);
                }
            }

            if (vehicles == null)
            {
                return;
            }

            foreach (VehicleController vehicle in vehicles)
            {
                if (vehicle == null) continue;
                if (vehicle.emergencyVehicle)
                {
                    ApplyEmergencyLighting(vehicle);
                }
                else
                {
                    ApplyNormalVehicleWave(vehicle);
                }
            }
        }

        public void TriggerSensorFault()
        {
            SetZoneBrightness("A", 1, 0.70f);
        }

        public void TriggerCommunicationFault()
        {
            SetZoneBrightness("B", 2, 0.70f);
        }

        public void TriggerSafeFallbackVisualization()
        {
            SetAllBrightness(0.70f);
        }

        public void TriggerNormalVehicleA()
        {
            SetZoneBrightness("A", 0, 1.0f);
        }

        public void TriggerNormalVehicleB()
        {
            SetZoneBrightness("B", 0, 1.0f);
        }

        public void TriggerEmergencyVehicleA()
        {
            SetDirectionBrightness("A", 1f);
        }

        public void TriggerEmergencyVehicleB()
        {
            SetDirectionBrightness("B", 1f);
        }

        public int NearestPoleIndex(float positionAlongRoad)
        {
            return Mathf.Clamp(Mathf.RoundToInt(positionAlongRoad / poleSpacingM), 0, numPoles - 1);
        }

        private void ClearGeneratedObjects()
        {
            _poles.Clear();
            _luminaires.Clear();
            _lightHoldUntil.Clear();
            for (int i = transform.childCount - 1; i >= 0; i--)
            {
                Transform child = transform.GetChild(i);
                if (Application.isPlaying)
                {
                    Destroy(child.gameObject);
                }
                else
                {
                    DestroyImmediate(child.gameObject);
                }
            }
        }

        private void CreateRoad()
        {
            CreateMountainValley();

            CreateCube(
                "reflective wet asphalt highway",
                new Vector3(RoadLengthM / 2f, -0.08f, 0f),
                new Vector3(RoadLengthM + 140f, 0.12f, 26.5f),
                roadMaterial
            );

            CreateCube("left shoulder", new Vector3(RoadLengthM / 2f, -0.06f, 15.2f), new Vector3(RoadLengthM + 120f, 0.08f, 3.1f), roadMaterial);
            CreateCube("right shoulder", new Vector3(RoadLengthM / 2f, -0.06f, -15.2f), new Vector3(RoadLengthM + 120f, 0.08f, 3.1f), roadMaterial);
            CreateCube("central concrete median", new Vector3(RoadLengthM / 2f, 0.20f, 0f), new Vector3(RoadLengthM + 90f, 0.45f, 0.54f), medianMaterial);

            CreateLaneMarkers();
            CreateGuardRails();
        }

        private void CreateMountainValley()
        {
            CreateMountainSlope("north green mountain wall", 1);
            CreateMountainSlope("south green mountain wall", -1);
            CreateTreeRows(1);
            CreateTreeRows(-1);
        }

        private void CreateMountainSlope(string name, int side)
        {
            int segments = Mathf.Max(18, numPoles);
            float length = RoadLengthM + 180f;
            float startX = -90f;
            Vector3[] vertices = new Vector3[(segments + 1) * 3];
            Vector2[] uvs = new Vector2[vertices.Length];
            int[] triangles = new int[segments * 12];

            for (int i = 0; i <= segments; i++)
            {
                float t = i / (float)segments;
                float x = startX + t * length;
                float wave = Mathf.Sin(t * Mathf.PI * 4.0f + side * 0.65f) * 0.5f + Mathf.Sin(t * Mathf.PI * 9.0f) * 0.25f;
                float ridgeHeight = 18f + wave * 6f;
                int baseIndex = i * 3;
                vertices[baseIndex] = new Vector3(x, -0.16f, side * 18.8f);
                vertices[baseIndex + 1] = new Vector3(x, 5.8f + wave * 1.8f, side * 48f);
                vertices[baseIndex + 2] = new Vector3(x, ridgeHeight, side * 92f);
                uvs[baseIndex] = new Vector2(t * 12f, 0f);
                uvs[baseIndex + 1] = new Vector2(t * 12f, 0.48f);
                uvs[baseIndex + 2] = new Vector2(t * 12f, 1f);
            }

            int triangleIndex = 0;
            for (int i = 0; i < segments; i++)
            {
                int a = i * 3;
                int b = (i + 1) * 3;
                triangles[triangleIndex++] = a;
                triangles[triangleIndex++] = b;
                triangles[triangleIndex++] = a + 1;
                triangles[triangleIndex++] = b;
                triangles[triangleIndex++] = b + 1;
                triangles[triangleIndex++] = a + 1;
                triangles[triangleIndex++] = a + 1;
                triangles[triangleIndex++] = b + 1;
                triangles[triangleIndex++] = a + 2;
                triangles[triangleIndex++] = b + 1;
                triangles[triangleIndex++] = b + 2;
                triangles[triangleIndex++] = a + 2;
            }

            GameObject slope = new GameObject(name);
            slope.transform.parent = transform;
            MeshFilter filter = slope.AddComponent<MeshFilter>();
            MeshRenderer renderer = slope.AddComponent<MeshRenderer>();
            Mesh mesh = new Mesh
            {
                name = name
            };
            mesh.vertices = vertices;
            mesh.uv = uvs;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            filter.sharedMesh = mesh;
            if (mountainMaterial != null)
            {
                renderer.sharedMaterial = mountainMaterial;
            }
        }

        private void CreateTreeRows(int side)
        {
            for (float x = -45f; x < RoadLengthM + 70f; x += 28f)
            {
                float offset = Mathf.Sin(x * 0.061f + side * 1.7f) * 5f;
                CreateConifer(new Vector3(x, 0f, side * (29f + Mathf.Abs(offset))), side);
                if (Mathf.Abs(Mathf.Sin(x * 0.037f)) > 0.35f)
                {
                    CreateConifer(new Vector3(x + 9f, 0.3f, side * (40f + Mathf.Abs(offset) * 0.8f)), side);
                }
            }
        }

        private void CreateConifer(Vector3 position, int side)
        {
            GameObject tree = new GameObject("dark roadside conifer");
            tree.transform.parent = transform;
            tree.transform.position = position;
            tree.transform.rotation = Quaternion.Euler(0f, side > 0 ? 8f : -8f, 0f);

            GameObject trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            trunk.name = "trunk";
            trunk.transform.SetParent(tree.transform, false);
            trunk.transform.localPosition = new Vector3(0f, 0.85f, 0f);
            trunk.transform.localScale = new Vector3(0.14f, 0.85f, 0.14f);
            trunk.GetComponent<Renderer>().sharedMaterial = mountainMaterial;

            for (int i = 0; i < 3; i++)
            {
                GameObject foliage = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                foliage.name = $"foliage tier {i + 1}";
                foliage.transform.SetParent(tree.transform, false);
                foliage.transform.localPosition = new Vector3(0f, 1.45f + i * 0.65f, 0f);
                float scale = 2.2f - i * 0.42f;
                foliage.transform.localScale = new Vector3(scale * 0.72f, 0.82f, scale * 0.72f);
                if (forestMaterial != null)
                {
                    foliage.GetComponent<Renderer>().sharedMaterial = forestMaterial;
                }
            }
        }

        private void CreateLaneMarkers()
        {
            float[] solidZ = { -11.15f, -0.52f, 0.52f, 11.15f };
            foreach (float z in solidZ)
            {
                CreateCube("solid lane boundary", new Vector3(RoadLengthM / 2f, 0.015f, z), new Vector3(RoadLengthM + 80f, 0.035f, 0.08f), laneMarkerMaterial);
            }

            float[] dashedZ = { -7.4f, -3.7f, 3.7f, 7.4f };
            for (float x = 0f; x < RoadLengthM + 20f; x += 22f)
            {
                foreach (float z in dashedZ)
                {
                    CreateCube("dashed lane marker", new Vector3(x, 0.02f, z), new Vector3(9.5f, 0.035f, 0.07f), laneMarkerMaterial);
                }
            }
        }

        private void CreateGuardRails()
        {
            for (float x = -20f; x < RoadLengthM + 40f; x += 8f)
            {
                CreateCube("guardrail post A", new Vector3(x, 0.52f, 16.85f), new Vector3(0.16f, 1.0f, 0.16f), guardrailMaterial);
                CreateCube("guardrail post B", new Vector3(x, 0.52f, -16.85f), new Vector3(0.16f, 1.0f, 0.16f), guardrailMaterial);
            }
            CreateCube("guardrail beam A", new Vector3(RoadLengthM / 2f, 1.02f, 16.85f), new Vector3(RoadLengthM + 110f, 0.18f, 0.20f), guardrailMaterial);
            CreateCube("guardrail beam B", new Vector3(RoadLengthM / 2f, 1.02f, -16.85f), new Vector3(RoadLengthM + 110f, 0.18f, 0.20f), guardrailMaterial);
        }

        private PoleManager CreatePole(string poleId, int index, string zoneId, float x)
        {
            GameObject root = new GameObject(poleId);
            root.transform.parent = transform;
            PoleManager pole = root.AddComponent<PoleManager>();
            pole.Initialize(poleId, index, zoneId, x);

            GameObject mast = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            mast.name = $"{poleId} galvanized mast";
            mast.transform.parent = root.transform;
            mast.transform.localPosition = new Vector3(0f, 4.25f, 0f);
            mast.transform.localScale = new Vector3(0.18f, 4.25f, 0.18f);
            if (poleMaterial != null)
            {
                mast.GetComponent<Renderer>().sharedMaterial = poleMaterial;
            }

            CreateArm(root.transform, "A", new Vector3(0f, 8.45f, 2.95f));
            CreateArm(root.transform, "B", new Vector3(0f, 8.45f, -2.95f));
            pole.luminaireA = CreateLuminaire(root.transform, poleId, "A", x, new Vector3(0f, 8.56f, 5.8f), new Vector3(60f, 0f, 0f));
            pole.luminaireB = CreateLuminaire(root.transform, poleId, "B", x, new Vector3(0f, 8.56f, -5.8f), new Vector3(120f, 0f, 180f));
            return pole;
        }

        private void CreateArm(Transform parent, string direction, Vector3 localPosition)
        {
            GameObject arm = GameObject.CreatePrimitive(PrimitiveType.Cube);
            arm.name = $"curved luminaire arm {direction}";
            arm.transform.parent = parent;
            arm.transform.localPosition = localPosition;
            arm.transform.localScale = new Vector3(0.16f, 0.12f, 5.9f);
            if (poleMaterial != null)
            {
                arm.GetComponent<Renderer>().sharedMaterial = poleMaterial;
            }
        }

        private LuminaireController CreateLuminaire(Transform parent, string poleId, string direction, float roadX, Vector3 localPosition, Vector3 euler)
        {
            GameObject luminaireObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            luminaireObject.name = $"{poleId}-{direction}";
            luminaireObject.transform.parent = parent;
            luminaireObject.transform.localPosition = localPosition;
            luminaireObject.transform.localRotation = Quaternion.Euler(euler);
            luminaireObject.transform.localScale = new Vector3(1.65f, 0.22f, 0.72f);
            if (lensMaterial != null)
            {
                luminaireObject.GetComponent<Renderer>().sharedMaterial = lensMaterial;
            }

            LuminaireController controller = luminaireObject.AddComponent<LuminaireController>();
            controller.luminaireId = $"{poleId}-{direction}";
            controller.poleId = poleId;
            controller.direction = direction;
            controller.lensRenderer = luminaireObject.GetComponent<Renderer>();
            controller.roadwayLight = CreateRoadwayBeam(luminaireObject.transform, direction, roadX);
            controller.ForceBrightness(ecoBrightness);
            return controller;
        }

        private Light CreateRoadwayBeam(Transform luminaire, string direction, float roadX)
        {
            GameObject beam = new GameObject("directional roadway beam");
            beam.transform.SetParent(luminaire, false);
            beam.transform.position = luminaire.position;
            float targetZ = direction == "A" ? 6.4f : -6.4f;
            Vector3 target = new Vector3(roadX + 7f, 0.05f, targetZ);
            beam.transform.rotation = Quaternion.LookRotation(target - beam.transform.position, Vector3.up);

            Light light = beam.AddComponent<Light>();
            light.type = LightType.Spot;
            light.range = 62f;
            light.spotAngle = 66f;
            light.innerSpotAngle = 42f;
            light.shadows = LightShadows.Soft;
            light.color = new Color(1f, 0.86f, 0.58f);
            return light;
        }

        private void ApplyNormalVehicleWave(VehicleController vehicle)
        {
            int nearest = NearestPoleIndex(vehicle.PositionAlongRoad);
            int sign = vehicle.direction == "A" ? 1 : -1;
            int aheadCount = LightsAhead(vehicle.speedMps);
            for (int offset = 0; offset <= aheadCount; offset++)
            {
                int poleIndex = nearest + offset * sign;
                if (poleIndex < 0 || poleIndex >= numPoles) continue;
                string luminaireId = $"P{poleIndex + 1:000}-{vehicle.direction}";
                if (_luminaires.ContainsKey(luminaireId))
                {
                    float distance = Mathf.Abs(poleIndex * poleSpacingM - vehicle.PositionAlongRoad);
                    float eta = distance / Mathf.Max(vehicle.speedMps, 0.1f);
                    float brightness = offset == 0 ? 1f : Mathf.Clamp(0.95f - eta * 0.035f - offset * 0.025f, heldBrightness, 1f);
                    SetLuminaireTarget(luminaireId, brightness, true, vehicle.speedMps);
                }
            }
        }

        private void ApplyEmergencyLighting(VehicleController vehicle)
        {
            int currentZone = NearestPoleIndex(vehicle.PositionAlongRoad) / zoneSizePoles;
            int sign = vehicle.direction == "A" ? 1 : -1;
            for (int zoneOffset = -1; zoneOffset <= 2; zoneOffset++)
            {
                int zone = currentZone + zoneOffset * sign;
                if (zone < 0 || zone * zoneSizePoles >= numPoles) continue;
                SetZoneBrightness(vehicle.direction, zone, emergencyBrightness, true, vehicle.speedMps);
            }
        }

        private int LightsAhead(float speedMps)
        {
            if (speedMps < 12f) return 4;
            if (speedMps < 22f) return 6;
            return 8;
        }

        private GameObject CreateCube(string name, Vector3 position, Vector3 scale, Material material)
        {
            GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.name = name;
            cube.transform.parent = transform;
            cube.transform.position = position;
            cube.transform.localScale = scale;
            if (material != null)
            {
                cube.GetComponent<Renderer>().sharedMaterial = material;
            }
            return cube;
        }

        private void HandleMqttMessage(string topic, string payload)
        {
            if (!topic.Contains("/luminaire/") || !topic.EndsWith("/brightness"))
            {
                return;
            }

            LuminaireState state = JsonUtility.FromJson<LuminaireState>(payload);
            if (state == null || string.IsNullOrEmpty(state.luminaire_id))
            {
                return;
            }

            ApplyLuminaireState(state);
        }

        public void ApplyLuminaireState(LuminaireState state)
        {
            if (_luminaires.TryGetValue(state.luminaire_id, out LuminaireController luminaire))
            {
                luminaire.SetTarget(Mathf.Clamp01(state.current_brightness));
            }
        }

        private void SetLuminaireTarget(string luminaireId, float brightness, bool holdAfterVehicle, float vehicleSpeedMps = 16f)
        {
            if (_luminaires.TryGetValue(luminaireId, out LuminaireController luminaire))
            {
                luminaire.SetTarget(Mathf.Max(luminaire.targetBrightness, Mathf.Clamp01(brightness)));
                if (holdAfterVehicle)
                {
                    _lightHoldUntil[luminaireId] = Time.time + HoldSecondsForSpeed(vehicleSpeedMps);
                }
            }
        }

        private float HoldSecondsForSpeed(float speedMps)
        {
            float secondsToNextPole = poleSpacingM / Mathf.Max(speedMps, 1f);
            return Mathf.Clamp(secondsToNextPole * 1.15f, 1.1f, lightHoldSeconds);
        }

        private void SetAllBrightness(float brightness)
        {
            foreach (LuminaireController luminaire in _luminaires.Values)
            {
                luminaire.SetTarget(brightness);
            }
        }

        private void SetDirectionBrightness(string direction, float brightness)
        {
            foreach (LuminaireController luminaire in _luminaires.Values)
            {
                if (luminaire.direction == direction)
                {
                    luminaire.SetTarget(brightness);
                }
            }
        }

        private void SetZoneBrightness(string direction, int zoneIndex, float brightness, bool holdAfterVehicle = false, float vehicleSpeedMps = 16f)
        {
            int start = zoneIndex * zoneSizePoles;
            int end = Mathf.Min(numPoles, start + zoneSizePoles);
            for (int i = start; i < end; i++)
            {
                string luminaireId = $"P{i + 1:000}-{direction}";
                SetLuminaireTarget(luminaireId, brightness, holdAfterVehicle, vehicleSpeedMps);
            }
        }
    }
}
