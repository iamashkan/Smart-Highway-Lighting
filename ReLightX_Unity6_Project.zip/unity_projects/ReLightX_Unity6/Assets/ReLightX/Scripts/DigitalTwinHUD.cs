using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace ReLightX
{
    public class DigitalTwinHUD : MonoBehaviour
    {
        public TrafficSimulationManager traffic;
        public DigitalTwinCameraRig cameraRig;
        public Text statusText;
        public Text selectedVehicleText;
        public Text roadVehicleListText;
        public Text processText;

        private void Start()
        {
            if (traffic == null) traffic = FindObjectOfType<TrafficSimulationManager>();
            if (cameraRig == null) cameraRig = FindObjectOfType<DigitalTwinCameraRig>();
        }

        private void Update()
        {
            if (traffic != null && statusText != null)
            {
                statusText.text =
                    $"Mode: {(traffic.emergencyActive ? "EMERGENCY" : "ADAPTIVE ECO")}\n" +
                    $"Traffic: {traffic.activeVehicleCount} vehicles\n" +
                    $"On road: {traffic.roadVehicleCount} vehicles\n" +
                    $"Closest gap: {(traffic.closestGapM > 200f ? "--" : traffic.closestGapM.ToString("0.0") + " m")}\n" +
                    $"Auto spawn: {(traffic.autoTraffic ? "on" : "paused")}";
            }

            if (cameraRig != null && selectedVehicleText != null)
            {
                VehicleController vehicle = cameraRig.selectedVehicle;
                selectedVehicleText.text = vehicle == null
                    ? "Selected vehicle: none\nClick any car to follow it.\nKeys: 1 overview, 2 third, 3 first, 4 side, 5 cinematic."
                    : $"Selected: {vehicle.vehicleId}\nType: {vehicle.vehicleType}\nLane: {vehicle.laneId}\nSpeed: {vehicle.speedMps:0.0} m/s\nView: {cameraRig.ModeLabel}";
            }

            if (traffic != null && processText != null)
            {
                processText.text =
                    $"Last event: {traffic.lastEvent}\n" +
                    "Lighting process: radar detect -> nearest pole -> direction wave -> smooth fade -> energy/health telemetry";
            }

            if (traffic != null && roadVehicleListText != null)
            {
                VehicleController[] roadVehicles = traffic.Vehicles
                    .Where(traffic.IsInsideRoad)
                    .OrderBy(vehicle => vehicle.PositionAlongRoad)
                    .Take(6)
                    .ToArray();

                if (roadVehicles.Length == 0)
                {
                    roadVehicleListText.text = "Cars on road: none\nUse Car A/B or Emerg A/B to spawn one.";
                }
                else
                {
                    roadVehicleListText.text = "Cars on road:\n" + string.Join(
                        "\n",
                        roadVehicles.Select(vehicle =>
                            $"{(vehicle.selected ? "> " : "  ")}{vehicle.vehicleId}  {vehicle.laneId}  {vehicle.speedMps:0.0} m/s")
                    );
                }
            }
        }
    }
}
